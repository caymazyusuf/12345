/* tslint:disable */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI, LiveServerMessage, Modality, Session} from '@google/genai';
import {LitElement, css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {createBlob, decode, decodeAudioData} from './utils';
import './visual-3d';

@customElement('gdm-live-audio')
export class GdmLiveAudio extends LitElement {
  @state() isRecording = false;
  @state() status = '';
  @state() error = '';

  private client: GoogleGenAI;
  private session: Session;
  private inputAudioContext = new (window.AudioContext ||
    (window as any).webkitAudioContext)({sampleRate: 16000});
  private outputAudioContext = new (window.AudioContext ||
    (window as any).webkitAudioContext)({sampleRate: 24000});
  @state() inputNode = this.inputAudioContext.createGain();
  @state() outputNode = this.outputAudioContext.createGain();
  private nextStartTime = 0;
  private mediaStream: MediaStream;
  private sourceNode: AudioBufferSourceNode;
  private scriptProcessorNode: ScriptProcessorNode;
  private sources = new Set<AudioBufferSourceNode>();

  static styles = css`
    #status {
      position: absolute;
      bottom: 5vh;
      left: 0;
      right: 0;
      z-index: 10;
      text-align: center;
      color: white; /* Added for better visibility */
      font-family: sans-serif; /* Added for better readability */
    }

    .controls {
      z-index: 10;
      position: absolute;
      bottom: 10vh;
      left: 0;
      right: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 10px;

      button {
        outline: none;
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.1);
        width: 64px;
        height: 64px;
        cursor: pointer;
        font-size: 24px;
        padding: 0;
        margin: 0;
        display: flex; /* Added for centering icon */
        align-items: center; /* Added for centering icon */
        justify-content: center; /* Added for centering icon */

        &:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      }

      button[disabled] {
        display: none;
      }
    }
  `;

  constructor() {
    super();
    this.initClient();
  }

  private initAudio() {
    this.nextStartTime = this.outputAudioContext.currentTime;
  }

  private async initClient() {
    this.initAudio();

    // IMPORTANT: Make sure process.env.GEMINI_API_KEY is configured in your environment.
    this.client = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
    });

    this.outputNode.connect(this.outputAudioContext.destination);

    this.initSession();
  }

  private async initSession() {
    const model = 'gemini-2.5-flash-preview-native-audio-dialog';

    try {
      this.session = await this.client.live.connect({
        model: model,
        callbacks: {
          onopen: () => {
            this.updateStatus('Bağlantı kuruldu');
          },
          onmessage: async (message: LiveServerMessage) => {
            const audio =
              message.serverContent?.modelTurn?.parts[0]?.inlineData;

            if (audio) {
              this.nextStartTime = Math.max(
                this.nextStartTime,
                this.outputAudioContext.currentTime,
              );

              const audioBuffer = await decodeAudioData(
                decode(audio.data),
                this.outputAudioContext,
                24000,
                1,
              );
              const source = this.outputAudioContext.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(this.outputNode);
              source.addEventListener('ended', () =>{
                this.sources.delete(source);
              });

              source.start(this.nextStartTime);
              this.nextStartTime = this.nextStartTime + audioBuffer.duration;
              this.sources.add(source);
            }

            const interrupted = message.serverContent?.interrupted;
            if(interrupted) {
              for(const source of this.sources.values()) {
                source.stop();
                this.sources.delete(source);
              }
              this.nextStartTime = 0;
            }
          },
          onerror: (e: ErrorEvent) => {
            this.updateError(e.message);
          },
          onclose: (e: CloseEvent) => {
            this.updateStatus('Bağlantı kesildi: ' + e.reason);
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            // Belirli bir voiceConfig kaldırıldı. API, languageCode'a göre
            // varsayılan bir Türkçe ses seçecektir. Bu, "sadece Türkiye Türkçesi"
            // kullanımını daha kesin hale getirir.
            languageCode: 'tr-TR'
          },
        },
      });
    } catch (e) {
      console.error(e);
      this.updateError(`Hata: ${e.message}`);
    }
  }

  private updateStatus(msg: string) {
    this.status = msg;
    this.error = ''; // Clear previous errors when a new status is set
  }

  private updateError(msg: string) {
    this.error = `Hata: ${msg}`;
    this.status = ''; // Clear status when an error occurs
  }

  private async startRecording() {
    if (this.isRecording) {
      return;
    }

    this.inputAudioContext.resume();

    this.updateStatus('Mikrofon erişimi isteniyor...');

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });

      this.updateStatus('Mikrofon erişimi verildi. Kayıt başlıyor...');

      this.sourceNode = this.inputAudioContext.createMediaStreamSource(
        this.mediaStream,
      );
      this.sourceNode.connect(this.inputNode);

      const bufferSize = 256; // Standard buffer size
      this.scriptProcessorNode = this.inputAudioContext.createScriptProcessor(
        bufferSize,
        1, // input channels
        1, // output channels
      );

      this.scriptProcessorNode.onaudioprocess = (audioProcessingEvent) => {
        if (!this.isRecording) return;

        const inputBuffer = audioProcessingEvent.inputBuffer;
        const pcmData = inputBuffer.getChannelData(0); // Assuming mono audio

        this.session.sendRealtimeInput({media: createBlob(pcmData)});
      };

      this.sourceNode.connect(this.scriptProcessorNode);
      // It's often not necessary to connect the scriptProcessorNode to the destination
      // if you're only capturing audio and not playing it back through this node.
      // However, some browsers might require it to keep the audio processing active.
      this.scriptProcessorNode.connect(this.inputAudioContext.destination);


      this.isRecording = true;
      this.updateStatus('🔴 Kaydediliyor... PCM verileri yakalanıyor.');
    } catch (err) {
      console.error('Kayıt başlatılırken hata:', err);
      this.updateError(`${err.message}`);
      this.stopRecording(); // Ensure cleanup if start fails
    }
  }

  private stopRecording() {
    if (!this.isRecording && !this.mediaStream && !this.inputAudioContext) {
        // Only update status if an actual recording was in progress or attempted
        if (this.status.startsWith('🔴')) {
            this.updateStatus('Kayıt durduruldu. Yeniden başlamak için Başlat\'a tıklayın.');
        }
        return;
    }


    this.updateStatus('Kayıt durduruluyor...');
    this.isRecording = false;

    if (this.scriptProcessorNode) {
      this.scriptProcessorNode.disconnect();
      this.scriptProcessorNode.onaudioprocess = null; // Remove the event listener
      this.scriptProcessorNode = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    
    // Don't close inputAudioContext here, it might be needed for subsequent recordings.
    // It's generally managed by the browser lifecycle or can be closed explicitly if the app is ending.

    this.updateStatus('Kayıt durduruldu. Yeniden başlamak için Başlat\'a tıklayın.');
  }

  private reset() {
    if (this.isRecording) {
        this.stopRecording(); // Stop recording before resetting
    }
    this.session?.close();
    // Wait a bit before re-initializing to ensure the old session is fully closed.
    setTimeout(() => {
        this.initAudio(); // Re-initialize audio components if necessary
        this.initSession();
        this.updateStatus('Oturum temizlendi. Başlamaya hazır.');
    }, 100); // 100ms delay, adjust as needed
  }

  render() {
    // Display error message if present, otherwise display status
    const messageToDisplay = this.error || this.status;
    return html`
      <div>
        <div class="controls">
          <button
            id="resetButton"
            aria-label="Oturumu Sıfırla"
            @click=${this.reset}
            ?disabled=${this.isRecording}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              height="40px"
              viewBox="0 -960 960 960"
              width="40px"
              fill="currentColor">
              <path
                d="M480-160q-134 0-227-93t-93-227q0-134 93-227t227-93q69 0 132 28.5T720-690v-110h80v280H520v-80h168q-32-56-87.5-88T480-720q-100 0-170 70t-70 170q0 100 70 170t170 70q77 0 139-44t87-116h84q-28 106-114 173t-196 67Z" />
            </svg>
          </button>
          <button
            id="startButton"
            aria-label="Kaydı Başlat"
            @click=${this.startRecording}
            ?disabled=${this.isRecording}>
            <svg
              viewBox="0 0 100 100"
              width="32px"
              height="32px"
              fill="#c80000"
              xmlns="http://www.w3.org/2000/svg">
              <circle cx="50" cy="50" r="50" />
            </svg>
          </button>
          <button
            id="stopButton"
            aria-label="Kaydı Durdur"
            @click=${this.stopRecording}
            ?disabled=${!this.isRecording}>
            <svg
              viewBox="0 0 100 100"
              width="32px"
              height="32px"
              fill="#000000" 
              xmlns="http://www.w3.org/2000/svg">
              <rect x="0" y="0" width="100" height="100" rx="15" />
            </svg>
          </button>
        </div>

        <div id="status" role="status" aria-live="polite"> ${messageToDisplay} </div>
        <gdm-live-audio-visuals-3d
          .inputNode=${this.inputNode}
          .outputNode=${this.outputNode}></gdm-live-audio-visuals-3d>
      </div>
    `;
  }
}
// Ensure process.env.GEMINI_API_KEY is defined.
// This is a placeholder for build-time environment variable injection.
// In a real build setup (e.g., Vite, Webpack), you'd configure this.
if (process.env.NODE_ENV !== 'production') {
  // @ts-ignore
  process.env.GEMINI_API_KEY = process.env.GEMINI_API_KEY ?? "YOUR_API_KEY"; // Fallback for local dev if not set
}